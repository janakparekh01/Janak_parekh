<?php
if(isset($_SESSION['user'])){
  echo"<script>
  window.location='index';
  </script>";
}

?>
<?php include_once('header.php')?>


  
    
    <script>
        function validate() {
            var email = document.getElementById("email").value;
            var password = document.getElementById("password").value;

            // Validate if both fields are empty
            if (email === "" || password === "") {
                document.getElementById("errorDiv1").innerText = "email are required.";
                document.getElementById("errorDiv").innerText = "password are required.";
                return false;
            }
            if(!(password.length >=3  && password.length <= 8))
	{ 
            document.getElementById("errorDiv2").innerText ="Please,provide min 3 & max 8 char in pass.";

		//alert('Please,provide min 3 & max 8 char in pass');
		return false;
	}

        }
        </script>



<!-- contact section -->
<section class="contact_section layout_padding">
    <div class="container">
      <div class="row">
        <div class="custom_heading-container ">
          <h2 align="center">
            Login form
          </h2>
        </div>
      </div>
    </div>
    <div class="container layout_padding2">
      <div class="row">
       <div class="offset-md-3 col-md-5">
          <div class="form_contaier">
            <form action="" method="post" onsubmit="return validate()">
              <div class="form-group">
                <label for="email">Email</label>
                <input type="email" name="email"  class="form-control" id="email">
                <div id="errorDiv1" style="color: red;"></div>

              </div>
              <div class="form-group">
                <label for="password">Password</label>
                <input type="password" name="password" class="form-control" id="password">
                <div id="errorDiv" style="color: red;"></div>

              </div>

              
              
              <button type="submit" name="submit">submit</button>
              <a class="float-right" href="signup">If you already then click signup</a>
            </form>
          </div>
        </div>
        
      </div>
    </div>
    <!-- <div id="errorDiv" style="color: red;"></div> -->

  </section>
  <?php
 
  ?>

  <!-- end contact section -->

  

  <!-- end info section -->
<?php 
include_once('footer.php');
?>