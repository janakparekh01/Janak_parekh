<?php
include_once('header.php');
?>

<div class="container-fluid bg-dark bg-img p-5 mb-5">
        <div class="row"> 
            <div class="col-12 text-center">
                <h1 class="display-4 text-uppercase text-white">Page Not Found</h1>
            </div>
        </div>
    </div>
	
	
<?php
include_once('footer.php');
?>