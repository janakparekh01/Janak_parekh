<?php 
include_once('header.php')
?>

<!-- contact section -->

<section class="contact_section layout_padding">
    <div class="container">
        <div class="row">
            <div class="custom_heading-container ">
                <h2 style="color: blue;text-align: center;">
                    Sign-up form
                </h2>
            </div>
        </div>
    </div>
    <div class="container layout_padding2">
        <div class="row">
            <div class="offset-md-3 col-md-6">
                <div class="form_contaier">
                    <form name="myform" action="" method="post" enctype="multipart/form-data" onsubmit="return validate()">
                        <div class="form-group">
                            <label for="name">Name<span style="color: red">*</span></label>
                            <input type="text" name="name" class="form-control">
                        </div>
                        <div class="form-group">
                            <label for="email">Email<span style="color: red">*</span></label>
                            <input type="email" name="email" class="form-control">
                        </div>
                        <div class="form-group">
                            <label for="password">Password<span style="color: red">*</span></label>
                            <input type="password" name="password" class="form-control">
                        </div>
                        <div class="form-group">
                            <label for="Gender">Gender<span style="color: red">*</span></label><br>
                            Male:<input type="radio" name="gender" value="male">
                            Female:<input type="radio" name="gender" value="female">
                            Others:<input type="radio" name="gender" value="others">
                        </div>
                        <div class="form-group">
                            <label for="Language">Language<span style="color: red">*</span></label><br>
                            English:<input type="checkbox" name="language[]" value="English">
                            Gujarati:<input type="checkbox" name="language[]" value="Gujarati">
                            Hindi:<input type="checkbox" name="language[]" value="Hindi">
                        </div>
                        <div class="form-group">
                            <label for="inputstate">Country<span style="color: red">*</span></label><br>
                            <select id="inputstate" name="c_id" class="form-control">
                                <option value="">Select Country</option>
                                <?php 
                                if(!empty($country_arr)){
                                    foreach($country_arr as $c){
                                ?>
                                <option value="<?php echo $c->c_id?>"><?php echo $c->country_name?></option>
                                <?php
                                    }
                                }
                                ?>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="image_upload">Image Upload<span style="color: red">*</span></label><br>
                            <input type="file" name="file" id="file" class="form-control">
                        </div>
                        <button type="submit" name="submit" class="">Submit</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</section>

<?php 
include_once('footer.php')
?>