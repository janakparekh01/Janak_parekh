<?php
include_once('../User/model.php');
class control extends model
{
	function __construct()
	{
		model::__construct();
		$url=$_SERVER['PATH_INFO'];
		switch($url)
		{
		
        case '/index':
		include_once('index.php');
		break;
		
		case '/add_cat':
		if(isset($_REQUEST['submit']))
		{
            $cat_name=$_REQUEST['cat_name'];
			
            $cat_img=$_FILES['cat_img']['name'];
            $path="../upload/category/".$cat_img;
            $tmp_file=$_FILES['cat_img']['tmp_name'];
            move_uploaded_file($tmp_file,$path);
			
            $created_at=date('Y-m-d H:i:s');
            $updated_at=date('Y-m-d H:i:s');
            //echo"<pre>";print_r($_REQUEST);exit;

            $arr=array("cat_name"=>$cat_name,"cat_img"=>$cat_img,"created_at"=>$created_at,"updated_at"=>$updated_at);
            $res=$this->insert('category',$arr);
			//echo"<pre>";print_r($res);exit;
            if($res)
			{
				//echo"<pre>";print_r($res);exit;
                echo "<script>
                alert('Category inserted success');
                </script>";
            }
            else
			{
                    echo "<script>
                    alert('not inserted');
                    </script>";
            }

        }
		include_once('add_cat.php');
		break;
		
		case '/add_emp':
		if(isset($_REQUEST['submit']))
		{
            $emp_name=$_REQUEST['emp_name'];
			$email=$_REQUEST['email'];
			$password=$_REQUEST['password'];
			$designation=$_REQUEST['designation'];
			
            $created_at=date('Y-m-d H:i:s');
            $updated_at=date('Y-m-d H:i:s');
            //echo"<pre>";print_r($_REQUEST);exit;

            $arr=array("emp_name"=>$emp_name,"email"=>$email,"password"=>$password,
			"designation"=>$designation,"created_at"=>$created_at,"updated_at"=>$updated_at);
            $res=$this->insert('employee',$arr);
			//echo"<pre>";print_r($res);exit;
            if($res)
			{
				//echo"<pre>";print_r($res);exit;
                echo "<script>
                alert('product inserted success');
                </script>";
            }
            else
			{
                    echo "<script>
                    alert('not inserted');
                    </script>";
            }

        }

		include_once('add_emp.php');
		break;
		
		case '/add_prod':
		if(isset($_REQUEST['submit']))
		{
            $product_name=$_REQUEST['product_name'];
			$discount_price=$_REQUEST['discount_price'];
			$main_price=$_REQUEST['main_price'];
			$description=$_REQUEST['description'];
			
            $file=$_FILES['file']['name'];
            $path="../upload/product/".$file;
            $tmp_file=$_FILES['file']['tmp_name'];
            move_uploaded_file($tmp_file,$path);
			
            $created_at=date('Y-m-d H:i:s');
            $updated_at=date('Y-m-d H:i:s');
            //echo"<pre>";print_r($_REQUEST);exit;

            $arr=array("product_name"=>$product_name,"discount_price"=>$discount_price,"main_price"=>$main_price,
			"description"=>$description,"file"=>$file,"created_at"=>$created_at,"updated_at"=>$updated_at);
            $res=$this->insert('products',$arr);
			//echo"<pre>";print_r($res);exit;
            if($res)
			{
				//echo"<pre>";print_r($res);exit;
                echo "<script>
                alert('product inserted success');
                </script>";
            }
            else
			{
                    echo "<script>
                    alert('not inserted');
                    </script>";
            }

        }
		include_once('add_prod.php');
		break;
		
		case '/login':
		include_once('login.php');
		break;
		
		case '/manage_cat':
		$data_category=$this->select('category');
		include_once('manage_cat.php');
		break;
		
		case '/editcat':
		if(isset($_REQUEST['editcat_id']))
		{
                $cat_id=$_REQUEST['editcat_id'];
                $where=array("cat_id"=>$cat_id);
                $run=$this->select_where('category',$where);
                $fetch=$run->fetch_object();


                if(isset($_REQUEST['submit']))
				{
					$cat_name=$_REQUEST['cat_name'];
					$updated_at=date("Y-m-d H:i:s");
				
				
					$cat_img=$_FILES['cat_img']['name'];
					$path="../upload/category/".$cat_img;
					$tmp_file=$_FILES['cat_img']['tmp_name'];
					move_uploaded_file($tmp_file,$path);
					$updated_at=date('Y-m-d H:i:s');
					//echo"<pre>";print_r($_REQUEST);exit;

					$arr=array("cat_name"=>$cat_name,"cat_img"=>$cat_img,"updated_at"=>$updated_at);
					$res=$this->update('category',$arr,$where);
					// echo"<pre>";
					// print_r($arr);
					// exit;
					if($res)
					{
						echo"<script>
                    
                        alert('Customer update Success');
                        window.location='manage_cat';
                    
                        </script>"; 
                    }
				}

				  
            }
		include_once('editcat.php');
		break;
		
		case '/editpro':
		if(isset($_REQUEST['editp_id']))
		{
                $p_id=$_REQUEST['editp_id'];
                $where=array("p_id"=>$p_id);
                $run=$this->select_where('products',$where);
                $fetch=$run->fetch_object();


                if(isset($_REQUEST['submit']))
				{
					$product_name=$_REQUEST['product_name'];
					$discount_price=$_REQUEST['discount_price'];
					$main_price=$_REQUEST['main_price'];
					$description=$_REQUEST['description'];
					$updated_at=date("Y-m-d H:i:s");
				
				
					$file=$_FILES['file']['name'];
					$path="../upload/category/".$file;
					$tmp_file=$_FILES['file']['tmp_name'];
					move_uploaded_file($tmp_file,$path);
					$updated_at=date('Y-m-d H:i:s');
					//echo"<pre>";print_r($_REQUEST);exit;

					$arr=array("product_name"=>$product_name,"discount_price"=>$discount_price,"main_price"=>$main_price,"description"=>$description,"file"=>$file,"updated_at"=>$updated_at);
					$res=$this->update('products',$arr,$where);
					// echo"<pre>";
					// print_r($arr);
					// exit;
					if($res)
					{
						echo"<script>
                    
                        alert('Customer update Success');
                        window.location='manage_prod';
                    
                        </script>"; 
                    }
				}

				  
            }
		include_once('editcat.php');
		break;
		
		case '/manage_prod':
		$data_products=$this->select('products');
		include_once('manage_prod.php');
		break;
		
		case '/manage_cust':
		$data_customers=$this->select('customers');
		include_once('manage_cust.php');
		break;
		
		
		case '/manage_emp':
		$data_employee=$this->select('employee');
		include_once('manage_emp.php');
		break;
		
		case '/manage_feed':
		$data_contact=$this->select('contact');
		include_once('manage_feed.php');
		break;
		
		case '/delete';
		 if(isset($_REQUEST['delcontact_id']))
		 {
            $contact_id=$_REQUEST['delcontact_id'];
            $where=array("contact_id"=>$contact_id);
            $res=$this->delete_where('contact',$where);
            if($res)
			{
                    echo "
                        <script>
                        alert('deleted data');
                        window.location='manage_feedback';
                        </script>
                        ";
            }
        }
		
		default:
		include_once('error.php');
		break;
		
		}
	}
}
$obj=new control;
?>